import { getCSRFToken } from './utils.js';
import { showToast } from './toast.js';

export async function loadSettings() {
    try {
        const response = await fetch('/api/settings');
        if (!response.ok) {
            if (response.status === 403) return; // Silent if not admin
            throw new Error('Failed to fetch settings');
        }
        const data = await response.json();
        if (data.success) {
            const pathInput = document.getElementById('settings-entrance-path');
            if (pathInput) {
                pathInput.value = data.entrance_path;
            }
        }
        await loadServiceStatus();
        await loadBackupSettings();
        await loadLogSettings();
        await loadUpdateStatus();
        await loadRegistries();
    } catch (err) {
        showToast('error', 'Error loading settings: ' + err.message);
    }
}

export async function submitSaveSettings() {
    const entrancePathInput = document.getElementById('settings-entrance-path');
    if (!entrancePathInput) return;

    const entrancePath = entrancePathInput.value.trim();
    if (!entrancePath) {
        showToast('error', 'Entrance path tidak boleh kosong');
        return;
    }

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-save-settings');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

        const response = await fetch('/api/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ entrance_path: entrancePath })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Pengaturan berhasil disimpan');
            // Refresh settings view
            entrancePathInput.value = data.entrance_path;
        } else {
            showToast('error', data.message || 'Gagal menyimpan pengaturan');
        }
    } catch (err) {
        showToast('error', 'Error saving settings: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function loadServiceStatus() {
    try {
        const response = await fetch('/api/settings/service-status');
        if (!response.ok) {
            throw new Error('Failed to fetch service status');
        }
        const res = await response.json();
        if (res.success && res.data) {
            const data = res.data;
            document.getElementById('service-distro').textContent = data.distro;
            document.getElementById('service-init-sys').textContent = data.init_system;

            const isRootEl = document.getElementById('service-is-root');
            if (data.is_root) {
                isRootEl.innerHTML = '<span style="color:#22c55e;"><i class="fa-solid fa-circle-check"></i> Yes</span>';
            } else {
                isRootEl.innerHTML = '<span style="color:#ef4444;"><i class="fa-solid fa-triangle-exclamation"></i> No (Running as user)</span>';
            }

            const badge = document.getElementById('service-status-badge');
            const installBtn = document.getElementById('btn-install-service');
            const uninstallBtn = document.getElementById('btn-uninstall-service');
            const manualContainer = document.getElementById('manual-instructions-container');

            if (data.status === 'active') {
                badge.textContent = 'Active (Running)';
                badge.style.background = 'rgba(34, 197, 94, 0.15)';
                badge.style.color = '#22c55e';
                badge.style.border = '1px solid rgba(34, 197, 94, 0.3)';

                installBtn.style.display = 'none';
                uninstallBtn.style.display = 'inline-block';

                if (!data.is_root) {
                    manualContainer.style.display = 'block';
                    document.getElementById('manual-title-label').textContent = 'Manual Service Uninstall';
                    document.getElementById('manual-config-sublabel').style.display = 'none';
                    document.getElementById('manual-config-box').style.display = 'none';
                    document.getElementById('manual-cmd-sublabel').textContent = 'Jalankan perintah ini di terminal Anda untuk mencopot service secara manual:';
                    document.getElementById('manual-install-cmd').value = data.uninstall_command;
                } else {
                    manualContainer.style.display = 'none';
                }
            } else if (data.status === 'inactive') {
                badge.textContent = 'Inactive (Stopped)';
                badge.style.background = 'rgba(234, 179, 8, 0.15)';
                badge.style.color = '#eab308';
                badge.style.border = '1px solid rgba(234, 179, 8, 0.3)';

                installBtn.style.display = 'inline-block';
                installBtn.innerHTML = '<i class="fa-solid fa-play"></i> Start Service';
                uninstallBtn.style.display = 'inline-block';

                if (!data.is_root) {
                    manualContainer.style.display = 'block';
                    document.getElementById('manual-title-label').textContent = 'Manual Service Uninstall';
                    document.getElementById('manual-config-sublabel').style.display = 'none';
                    document.getElementById('manual-config-box').style.display = 'none';
                    document.getElementById('manual-cmd-sublabel').textContent = 'Jalankan perintah ini di terminal Anda untuk mencopot service secara manual:';
                    document.getElementById('manual-install-cmd').value = data.uninstall_command;
                } else {
                    manualContainer.style.display = 'none';
                }
            } else {
                badge.textContent = 'Not Installed';
                badge.style.background = 'rgba(156, 163, 175, 0.15)';
                badge.style.color = '#9ca3af';
                badge.style.border = '1px solid rgba(156, 163, 175, 0.3)';

                installBtn.style.display = 'inline-block';
                installBtn.innerHTML = '<i class="fa-solid fa-plus"></i> Install Service';
                uninstallBtn.style.display = 'none';

                // Show manual instructions
                manualContainer.style.display = 'block';
                document.getElementById('manual-title-label').textContent = 'Manual Service Configuration';
                document.getElementById('manual-config-sublabel').style.display = 'block';
                document.getElementById('manual-config-box').style.display = 'block';
                document.getElementById('manual-cmd-sublabel').textContent = 'Jalankan perintah ini di terminal Anda untuk mendaftarkan service secara manual:';
                document.getElementById('service-config-content').textContent = data.service_content;
                document.getElementById('manual-install-cmd').value = data.install_command;
            }
        }
    } catch (err) {
        showToast('error', 'Error loading service status: ' + err.message);
    }
}

export async function installService() {
    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-install-service');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Installing...';

        const response = await fetch('/api/settings/service-install', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Service berhasil diinstall');
            await loadServiceStatus();
        } else {
            showToast('error', data.message || 'Gagal menginstall service secara otomatis');
            await loadServiceStatus();
        }
    } catch (err) {
        showToast('error', 'Error installing service: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function uninstallService() {
    if (!confirm('Apakah Anda yakin ingin mencopot service Zenopanel?')) return;

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-uninstall-service');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uninstalling...';

        const response = await fetch('/api/settings/service-uninstall', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Service berhasil dicopot');
            await loadServiceStatus();
        } else {
            showToast('error', data.message || 'Gagal mencopot service secara otomatis');
            await loadServiceStatus();
        }
    } catch (err) {
        showToast('error', 'Error uninstalling service: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export function copyInstallCmd() {
    const input = document.getElementById('manual-install-cmd');
    if (!input) return;
    input.select();
    navigator.clipboard.writeText(input.value)
        .then(() => showToast('success', 'Perintah berhasil disalin!'))
        .catch(() => showToast('error', 'Gagal menyalin perintah'));
}

export function toggleRateLimitFields() {
    const rlCheckbox = document.getElementById('settings-rl-enabled');
    const rlEnabled = rlCheckbox ? rlCheckbox.checked : false;
    const details = document.getElementById('rate-limit-details');
    if (details) {
        details.style.display = rlEnabled ? 'flex' : 'none';
    }
}

export async function loadSecuritySettings() {
    try {
        const tbody = document.getElementById('waf-logs-tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:30px;"><i class="fa-solid fa-spinner fa-spin"></i> Loading audit logs...</td></tr>';
        }

        const response = await fetch('/api/settings/security');
        if (!response.ok) {
            throw new Error('Failed to fetch security settings');
        }
        const data = await response.json();
        if (data.success) {
            const wafCheckbox = document.getElementById('settings-waf-enabled');
            if (wafCheckbox) {
                wafCheckbox.checked = data.settings.waf_enabled;
            }
            const dryRunCheckbox = document.getElementById('settings-waf-dry-run');
            if (dryRunCheckbox) {
                dryRunCheckbox.checked = data.settings.waf_dry_run;
            }
            const maxBodySizeInput = document.getElementById('settings-waf-max-body-size');
            if (maxBodySizeInput) {
                maxBodySizeInput.value = data.settings.waf_max_body_size;
            }
            const allowGoodBotsCheckbox = document.getElementById('settings-waf-allow-good-bots');
            if (allowGoodBotsCheckbox) {
                allowGoodBotsCheckbox.checked = data.settings.waf_allow_good_bots;
            }
            const customBadBotsTextarea = document.getElementById('settings-waf-custom-bad-bots');
            if (customBadBotsTextarea) {
                customBadBotsTextarea.value = data.settings.waf_custom_bad_bots || '';
            }
            const rlCheckbox = document.getElementById('settings-rl-enabled');
            if (rlCheckbox) {
                rlCheckbox.checked = data.settings.rate_limit_enabled;
            }

            const maxInput = document.getElementById('settings-rl-max');
            if (maxInput) {
                maxInput.value = data.settings.rate_limit_max;
            }

            const windowInput = document.getElementById('settings-rl-window');
            if (windowInput) {
                windowInput.value = data.settings.rate_limit_window;
            }

            toggleRateLimitFields();

            if (tbody) {
                if (!data.logs || data.logs.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:30px;">Belum ada log aktivitas keamanan terdeteksi.</td></tr>';
                } else {
                    tbody.innerHTML = data.logs.map(log => `
                        <tr>
                            <td>${log.id}</td>
                            <td><span style="font-family:var(--font-code); color:var(--accent-primary);">${log.ip}</span></td>
                            <td><span class="badge" style="background:rgba(239, 44, 44, 0.12); color:var(--danger); border:1px solid rgba(239, 44, 44, 0.1);">${escapeHtml(log.reason)}</span></td>
                            <td><span style="font-family:var(--font-code);">${escapeHtml(log.target)}</span></td>
                            <td style="color:var(--text-muted);">${formatDate(log.timestamp)}</td>
                        </tr>
                    `).join('');
                }
            }
            await loadFirewallRules();
        }
    } catch (err) {
        showToast('error', 'Error loading security settings: ' + err.message);
    }
}

export async function submitSaveSecurity() {
    const wafEnabled = document.getElementById('settings-waf-enabled').checked;
    const wafDryRun = document.getElementById('settings-waf-dry-run').checked;
    const wafMaxBodySize = parseInt(document.getElementById('settings-waf-max-body-size').value.trim(), 10) || 2;
    const wafAllowGoodBots = document.getElementById('settings-waf-allow-good-bots')?.checked ?? true;
    const wafCustomBadBots = (document.getElementById('settings-waf-custom-bad-bots')?.value || '').trim();
    const rateLimitEnabled = document.getElementById('settings-rl-enabled').checked;
    const rateLimitMax = parseInt(document.getElementById('settings-rl-max').value.trim(), 10) || 1000;
    const rateLimitWindow = parseInt(document.getElementById('settings-rl-window').value.trim(), 10) || 60;

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-save-security');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

        const response = await fetch('/api/settings/security', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                waf_enabled: wafEnabled,
                waf_dry_run: wafDryRun,
                waf_max_body_size: wafMaxBodySize,
                waf_allow_good_bots: wafAllowGoodBots,
                waf_custom_bad_bots: wafCustomBadBots,
                rate_limit_enabled: rateLimitEnabled,
                rate_limit_max: rateLimitMax,
                rate_limit_window: rateLimitWindow
            })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Pengaturan keamanan berhasil disimpan');
            await loadSecuritySettings();
        } else {
            showToast('error', data.message || 'Gagal menyimpan pengaturan keamanan');
        }
    } catch (err) {
        showToast('error', 'Error saving security settings: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function formatDate(dateStr) {
    if (!dateStr) return '-';
    try {
        const date = new Date(dateStr);
        return date.toLocaleString();
    } catch (e) {
        return dateStr;
    }
}

export function toggleBackupFields() {
    const backupCheckbox = document.getElementById('settings-backup-enabled');
    const enabled = backupCheckbox ? backupCheckbox.checked : false;
    const fields = document.getElementById('backup-settings-fields');
    if (fields) {
        fields.style.display = enabled ? 'flex' : 'none';
    }
}

export function toggleRemoteBackupFields() {
    const checkbox = document.getElementById('settings-backup-remote-enabled');
    const fields = document.getElementById('remote-backup-settings-fields');
    if (fields) {
        fields.style.display = checkbox && checkbox.checked ? 'flex' : 'none';
    }
}

export function toggleRemoteProviderFields() {
    const provider = document.getElementById('settings-backup-remote-provider')?.value;
    const s3Fields = document.getElementById('remote-backup-s3-fields');
    const gdriveFields = document.getElementById('remote-backup-gdrive-fields');
    if (s3Fields) s3Fields.style.display = provider === 's3' ? 'flex' : 'none';
    if (gdriveFields) gdriveFields.style.display = provider === 'gdrive' ? 'flex' : 'none';
}

// Bind to window so inline HTML onchange triggers can find them
window.toggleRemoteBackupFields = toggleRemoteBackupFields;
window.toggleRemoteProviderFields = toggleRemoteProviderFields;

export async function loadBackupSettings() {
    try {
        const response = await fetch('/api/settings/backup');
        if (!response.ok) {
            throw new Error('Failed to fetch backup settings');
        }
        const data = await response.json();
        if (data.success && data.settings) {
            const settings = data.settings;

            const backupEnabled = document.getElementById('settings-backup-enabled');
            if (backupEnabled) backupEnabled.checked = settings.enabled;

            const backupInterval = document.getElementById('settings-backup-interval');
            if (backupInterval) backupInterval.value = settings.interval_hours;

            const backupRetention = document.getElementById('settings-backup-retention');
            if (backupRetention) backupRetention.value = settings.retention;

            const backupDestDir = document.getElementById('settings-backup-dest-dir');
            if (backupDestDir) backupDestDir.value = settings.dest_dir;

            const backupPostScript = document.getElementById('settings-backup-post-script');
            if (backupPostScript) backupPostScript.value = settings.post_script;

            const backupLastRun = document.getElementById('backup-last-run-val');
            if (backupLastRun) backupLastRun.textContent = settings.last_run ? formatDate(settings.last_run) : 'Never';

            const backupLastStatus = document.getElementById('backup-last-status-val');
            if (backupLastStatus) backupLastStatus.textContent = settings.last_status || 'No status available';

            const remoteEnabled = document.getElementById('settings-backup-remote-enabled');
            if (remoteEnabled) remoteEnabled.checked = settings.remote_enabled;

            const remoteProvider = document.getElementById('settings-backup-remote-provider');
            if (remoteProvider) remoteProvider.value = settings.remote_provider || 's3';

            const s3Endpoint = document.getElementById('settings-backup-s3-endpoint');
            if (s3Endpoint) s3Endpoint.value = settings.s3_endpoint || '';

            const s3Bucket = document.getElementById('settings-backup-s3-bucket');
            if (s3Bucket) s3Bucket.value = settings.s3_bucket || '';

            const s3AccessKey = document.getElementById('settings-backup-s3-access-key');
            if (s3AccessKey) s3AccessKey.value = settings.s3_access_key || '';

            const s3SecretKey = document.getElementById('settings-backup-s3-secret-key');
            if (s3SecretKey) s3SecretKey.value = settings.s3_secret_key || '';

            const gdriveFolderId = document.getElementById('settings-backup-gdrive-folder-id');
            if (gdriveFolderId) gdriveFolderId.value = settings.gdrive_folder_id || '';

            const gdriveCredentials = document.getElementById('settings-backup-gdrive-credentials');
            if (gdriveCredentials) gdriveCredentials.value = settings.gdrive_credentials || '';

            const keepLocal = document.getElementById('settings-backup-keep-local');
            if (keepLocal) keepLocal.checked = settings.keep_local;

            toggleBackupFields();
            toggleRemoteBackupFields();
            toggleRemoteProviderFields();
        }
    } catch (err) {
        showToast('error', 'Error loading backup settings: ' + err.message);
    }
}

export async function submitSaveBackupSettings() {
    const backupEnabled = document.getElementById('settings-backup-enabled').checked;
    const backupInterval = parseInt(document.getElementById('settings-backup-interval').value.trim(), 10) || 24;
    const backupRetention = parseInt(document.getElementById('settings-backup-retention').value.trim(), 10) || 7;
    const backupDestDir = document.getElementById('settings-backup-dest-dir').value.trim() || '/var/lib/zenopanel/backups';
    const backupPostScript = document.getElementById('settings-backup-post-script').value.trim() || '';

    const remoteEnabled = document.getElementById('settings-backup-remote-enabled').checked;
    const remoteProvider = document.getElementById('settings-backup-remote-provider').value;
    const s3Endpoint = document.getElementById('settings-backup-s3-endpoint').value.trim();
    const s3Bucket = document.getElementById('settings-backup-s3-bucket').value.trim();
    const s3AccessKey = document.getElementById('settings-backup-s3-access-key').value.trim();
    const s3SecretKey = document.getElementById('settings-backup-s3-secret-key').value.trim();
    const gdriveFolderId = document.getElementById('settings-backup-gdrive-folder-id').value.trim();
    const gdriveCredentials = document.getElementById('settings-backup-gdrive-credentials').value.trim();
    const keepLocal = document.getElementById('settings-backup-keep-local').checked;

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-save-backup-settings');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

        const response = await fetch('/api/settings/backup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                enabled: backupEnabled,
                interval_hours: backupInterval,
                retention: backupRetention,
                dest_dir: backupDestDir,
                post_script: backupPostScript,
                remote_enabled: remoteEnabled,
                remote_provider: remoteProvider,
                s3_endpoint: s3Endpoint,
                s3_bucket: s3Bucket,
                s3_access_key: s3AccessKey,
                s3_secret_key: s3SecretKey,
                gdrive_folder_id: gdriveFolderId,
                gdrive_credentials: gdriveCredentials,
                keep_local: keepLocal
            })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Pengaturan backup berhasil disimpan');
            await loadBackupSettings();
        } else {
            showToast('error', data.message || 'Gagal menyimpan pengaturan backup');
        }
    } catch (err) {
        showToast('error', 'Error saving backup settings: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function triggerBackupManual() {
    if (!confirm('Apakah Anda yakin ingin memicu backup manual sekarang? Proses ini dapat memakan waktu beberapa saat.')) return;

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-trigger-backup');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Backing up...';

        const response = await fetch('/api/settings/backup/trigger', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', `${data.message}. File: ${data.filename}`);
            await loadBackupSettings();
        } else {
            showToast('error', data.message + (data.error ? ': ' + data.error : ''));
            await loadBackupSettings();
        }
    } catch (err) {
        showToast('error', 'Error triggering backup: ' + err.message);
        await loadBackupSettings();
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

// ─────────────────────────────────────────────────────────
// LOG ROTATION SETTINGS
// ─────────────────────────────────────────────────────────

export async function loadLogSettings() {
    try {
        const response = await fetch('/api/settings/logs');
        const data = await response.json();
        if (data.success && data.data) {
            const d = data.data;

            const intervalEl = document.getElementById('log-rotation-interval');
            const maxSizeEl = document.getElementById('log-max-size-mb');
            const wafRetEl = document.getElementById('log-waf-retention-days');
            const lastRotEl = document.getElementById('log-last-rotation-val');
            const lastStatusEl = document.getElementById('log-last-status-val');

            if (intervalEl) intervalEl.value = d.interval_hours ?? 24;
            if (maxSizeEl) maxSizeEl.value = d.max_size_mb ?? 10;
            if (wafRetEl) wafRetEl.value = d.waf_retention_days ?? 30;
            if (lastRotEl) lastRotEl.textContent = d.last_rotation || '-';
            if (lastStatusEl) lastStatusEl.textContent = d.last_status || '-';
        }
    } catch (err) {
        console.error('Error loading log settings:', err);
    }
}

export async function submitSaveLogSettings() {
    const btn = document.getElementById('btn-save-log-settings');
    if (!btn) return;
    const originalText = btn.innerHTML;
    const csrfToken = getCSRFToken ? getCSRFToken() : '';

    const payload = {
        interval_hours: parseInt(document.getElementById('log-rotation-interval')?.value || '24'),
        max_size_mb: parseInt(document.getElementById('log-max-size-mb')?.value || '10'),
        waf_retention_days: parseInt(document.getElementById('log-waf-retention-days')?.value || '30'),
    };

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';

        const response = await fetch('/api/settings/logs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Pengaturan log rotation berhasil disimpan');
        } else {
            showToast('error', data.message || 'Gagal menyimpan pengaturan');
        }
    } catch (err) {
        showToast('error', 'Error saving log settings: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function triggerLogRotation() {
    const btn = document.getElementById('btn-trigger-log-rotation');
    if (!btn) return;
    const originalText = btn.innerHTML;
    const csrfToken = getCSRFToken ? getCSRFToken() : '';

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Rotating...';

        const response = await fetch('/api/settings/logs/rotate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', `${data.message}. ${data.summary || ''}`);
            await loadLogSettings();
        } else {
            showToast('error', data.message || 'Gagal menjalankan log rotation');
            await loadLogSettings();
        }
    } catch (err) {
        showToast('error', 'Error triggering log rotation: ' + err.message);
        await loadLogSettings();
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export function openAddFirewallRuleModal() {
    const modal = document.getElementById('add-firewall-modal');
    if (modal) modal.classList.add('active');
}

export function closeAddFirewallRuleModal() {
    const modal = document.getElementById('add-firewall-modal');
    if (modal) modal.classList.remove('active');

    // Clear inputs
    document.getElementById('fw-rule-name').value = '';
    document.getElementById('fw-rule-port').value = '';
    document.getElementById('fw-rule-protocol').value = 'tcp';
    document.getElementById('fw-rule-action').value = 'ACCEPT';
}

export async function submitAddFirewallRule() {
    const name = document.getElementById('fw-rule-name').value.trim();
    const port = document.getElementById('fw-rule-port').value.trim();
    const protocol = document.getElementById('fw-rule-protocol').value;
    const action = document.getElementById('fw-rule-action').value;

    if (!name || !port) {
        showToast('error', 'Semua kolom wajib diisi');
        return;
    }

    const portNum = parseInt(port, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
        showToast('error', 'Port harus berupa angka antara 1 s/d 65535');
        return;
    }

    const csrfToken = getCSRFToken();
    try {
        const response = await fetch('/api/security/firewall/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ name, port: portNum.toString(), protocol, action })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Aturan firewall berhasil disimpan');
            closeAddFirewallRuleModal();
            await loadFirewallRules();
        } else {
            showToast('error', data.message || 'Gagal menyimpan aturan firewall');
        }
    } catch (err) {
        showToast('error', 'Error: ' + err.message);
    }
}

export async function deleteFirewallRule(name, port, protocol, action) {
    if (!confirm(`Apakah Anda yakin ingin menghapus aturan "${name}" (${protocol}/${port})?`)) return;

    const csrfToken = getCSRFToken();
    try {
        const response = await fetch('/api/security/firewall/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ name, port: port.toString(), protocol, action })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Aturan firewall berhasil dihapus');
            await loadFirewallRules();
        } else {
            showToast('error', data.message || 'Gagal menghapus aturan firewall');
        }
    } catch (err) {
        showToast('error', 'Error: ' + err.message);
    }
}

export async function loadFirewallRules() {
    try {
        const tbody = document.getElementById('firewall-rules-tbody');
        if (!tbody) return;

        // Fetch Lockdown Status as well!
        try {
            const ldResponse = await fetch('/api/security/firewall/lockdown');
            if (ldResponse.ok) {
                const ldData = await ldResponse.json();
                if (ldData.success) {
                    const ldCheckbox = document.getElementById('settings-fw-lockdown');
                    if (ldCheckbox) {
                        ldCheckbox.checked = ldData.enabled;
                    }
                }
            }
        } catch (ldErr) {
            console.error('Error fetching firewall lockdown status:', ldErr);
        }

        const response = await fetch('/api/security/firewall');
        if (!response.ok) {
            throw new Error('Failed to fetch firewall rules');
        }

        const data = await response.json();
        if (data.success) {
            const rules = data.data || [];
            if (rules.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:30px;">Belum ada aturan firewall terdaftar.</td></tr>';
            } else {
                tbody.innerHTML = rules.map(rule => {
                    const actionBadge = rule.action === 'ACCEPT'
                        ? `<span class="badge badge-running">ACCEPT</span>`
                        : `<span class="badge badge-stopped">DROP</span>`;

                    // Escape arguments for the delete action
                    const safeName = escapeHtml(rule.name);
                    const safePort = escapeHtml(rule.port);
                    const safeProtocol = escapeHtml(rule.protocol);
                    const safeAction = escapeHtml(rule.action);

                    return `
                        <tr>
                            <td><strong>${safeName}</strong></td>
                            <td><span style="font-family:var(--font-code); color:var(--accent-primary);">${safePort}</span></td>
                            <td><span class="badge" style="background:rgba(168, 85, 247, 0.12); color:var(--accent-secondary); border:1px solid rgba(168, 85, 247, 0.1);">${safeProtocol.toUpperCase()}</span></td>
                            <td>${actionBadge}</td>
                            <td style="text-align: right;">
                                <button class="btn-icon" onclick="deleteFirewallRule('${safeName}', '${safePort}', '${safeProtocol}', '${safeAction}')" title="Delete Rule">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                }).join('');
            }
        }
    } catch (err) {
        console.error('Error loading firewall rules:', err);
    }
}

export async function toggleFirewallLockdown() {
    const checkbox = document.getElementById('settings-fw-lockdown');
    if (!checkbox) return;

    const enabled = checkbox.checked;

    // If enabling, show confirmation modal to warn the user!
    if (enabled) {
        const confirmed = confirm(
            "PERINGATAN: Mengaktifkan Lockdown Mode akan memblokir SEMUA port masuk ke server ini (default DROP) secara otomatis, kecuali port SSH (22) dan port manajemen ZenoPanel (3000, 8443, 3001, 3002). Jika Anda menjalankan aplikasi lain pada port non-standar, port tersebut akan terblokir sampai Anda menambahkannya secara manual ke daftar aturan di bawah. Apakah Anda yakin ingin melanjutkan?"
        );
        if (!confirmed) {
            checkbox.checked = false;
            return;
        }
    } else {
        const confirmed = confirm(
            "Apakah Anda yakin ingin menonaktifkan Lockdown Mode? Kebijakan firewall default akan dikembalikan menjadi mengizinkan semua koneksi masuk (default ACCEPT)."
        );
        if (!confirmed) {
            checkbox.checked = true;
            return;
        }
    }

    const csrfToken = getCSRFToken();
    try {
        const response = await fetch('/api/security/firewall/lockdown', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ enabled })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Status lockdown berhasil diperbarui');
            await loadFirewallRules();
        } else {
            showToast('error', data.message || 'Gagal memperbarui status lockdown');
            checkbox.checked = !enabled; // Revert checkbox state
        }
    } catch (err) {
        showToast('error', 'Error: ' + err.message);
        checkbox.checked = !enabled; // Revert checkbox state
    }
}

export async function loadUpdateStatus(force = false) {
    try {
        const url = force ? '/api/info?force=true' : '/api/info';
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch version info');
        const res = await response.json();
        
        if (res.success && res.data) {
            const d = res.data;
            document.getElementById('update-current-ver').textContent = 'v' + (d.version || '-');
            document.getElementById('update-latest-ver').textContent = d.latest_version ? 'v' + d.latest_version : 'Checking...';

            const alertEl = document.getElementById('update-status-alert');
            const updateBtn = document.getElementById('btn-update-panel');

            if (d.update_available && d.latest_version) {
                alertEl.style.display = 'block';
                alertEl.style.background = 'rgba(239, 68, 68, 0.1)';
                alertEl.style.border = '1px solid rgba(239, 68, 68, 0.2)';
                alertEl.style.color = '#f87171';
                alertEl.innerHTML = `<i class="fa-solid fa-circle-exclamation"></i> Versi baru tersedia! Silakan perbarui ke versi <strong>v${d.latest_version}</strong>.`;
                updateBtn.style.display = 'inline-block';
            } else if (d.latest_version) {
                alertEl.style.display = 'block';
                alertEl.style.background = 'rgba(34, 197, 94, 0.1)';
                alertEl.style.border = '1px solid rgba(34, 197, 94, 0.2)';
                alertEl.style.color = '#4ade80';
                alertEl.innerHTML = `<i class="fa-solid fa-circle-check"></i> ZenoPanel Anda sudah menggunakan versi terbaru.`;
                updateBtn.style.display = 'none';
            } else {
                alertEl.style.display = 'none';
                updateBtn.style.display = 'none';
            }
        }
    } catch (err) {
        console.error('Error loading update status:', err);
    }
}

export async function checkUpdateManual() {
    const btn = document.querySelector('[onclick="checkUpdateManual()"]');
    const originalText = btn.innerHTML;
    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Checking...';
        await loadUpdateStatus(true);
        showToast('success', 'Pemeriksaan pembaruan selesai');
    } catch (err) {
        showToast('error', 'Gagal memeriksa pembaruan: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function triggerUpdatePanel() {
    if (!confirm('Apakah Anda yakin ingin memperbarui ZenoPanel sekarang? Sistem akan diunduh dan dimulai ulang otomatis dalam beberapa detik.')) {
        return;
    }

    const csrfToken = getCSRFToken();
    const btn = document.getElementById('btn-update-panel');
    const originalText = btn.innerHTML;

    try {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Updating...';

        const response = await fetch('/api/system/update', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            }
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', 'Update berhasil dipicu! Mengalihkan halaman dalam 5 detik...');
            setTimeout(() => {
                window.location.reload();
            }, 6000);
        } else {
            showToast('error', data.message || 'Gagal memulai pembaruan');
        }
    } catch (err) {
        showToast('error', 'Error memicu pembaruan: ' + err.message);
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalText;
    }
}

export async function loadRegistries() {
    try {
        const response = await fetch('/api/settings/registries');
        if (!response.ok) throw new Error('Failed to fetch registries');
        const data = await response.json();
        
        const container = document.getElementById('registry-list-container');
        if (!container) return;

        if (data.success && data.registries) {
            const list = data.registries;
            if (list.length === 0) {
                container.innerHTML = `
                    <div style="padding:15px; border-radius:6px; border:1px dashed var(--card-border); text-align:center; color:var(--text-muted); font-size:0.8rem;">
                        Belum ada private registry terdaftar.
                    </div>
                `;
            } else {
                container.innerHTML = list.map(reg => `
                    <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(255,255,255,0.02); border:1px solid var(--card-border); border-radius:6px; padding:10px 14px;">
                        <span style="font-family:var(--font-code); font-size:0.85rem; color:var(--text-main); font-weight:600; display:flex; align-items:center; gap:8px;">
                            <i class="fa-solid fa-server" style="color:var(--accent-secondary);"></i> ${escapeHtml(reg)}
                        </span>
                        <button class="btn-icon" onclick="deleteRegistry('${escapeHtml(reg)}')" title="Hapus Kredensial" style="padding:4px; font-size:0.85rem; border:none; background:transparent; cursor:pointer;">
                            <i class="fa-solid fa-trash" style="color:#ef4444;"></i>
                        </button>
                    </div>
                `).join('');
            }
        }
    } catch (err) {
        console.error('Error loading registries:', err);
    }
}

export function onRegistryDomainSelectChange() {
    const select = document.getElementById('registry-domain-select');
    const customGroup = document.getElementById('registry-domain-custom-group');
    if (select && customGroup) {
        customGroup.style.display = select.value === 'custom' ? 'block' : 'none';
    }
}

export async function submitAddRegistry() {
    const select = document.getElementById('registry-domain-select');
    if (!select) return;

    let registry = select.value;
    if (registry === 'custom') {
        registry = document.getElementById('registry-domain-custom').value.trim();
    }
    const username = document.getElementById('registry-username').value.trim();
    const password = document.getElementById('registry-password').value.trim();

    if (!registry || !username || !password) {
        showToast('error', 'Semua kolom registry, username, dan password wajib diisi');
        return;
    }

    const csrfToken = getCSRFToken();
    try {
        const response = await fetch('/api/settings/registries', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ registry, username, password })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Kredensial registry berhasil disimpan');
            document.getElementById('registry-username').value = '';
            document.getElementById('registry-password').value = '';
            document.getElementById('registry-domain-custom').value = '';
            await loadRegistries();
        } else {
            showToast('error', data.message || 'Gagal menyimpan kredensial registry');
        }
    } catch (err) {
        showToast('error', 'Error: ' + err.message);
    }
}

export async function deleteRegistry(registry) {
    if (!confirm(`Apakah Anda yakin ingin menghapus kredensial untuk registry "${registry}"?`)) return;

    const csrfToken = getCSRFToken();
    try {
        const response = await fetch('/api/settings/registries/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({ registry })
        });

        const data = await response.json();
        if (data.success) {
            showToast('success', data.message || 'Kredensial registry berhasil dihapus');
            await loadRegistries();
        } else {
            showToast('error', data.message || 'Gagal menghapus kredensial registry');
        }
    } catch (err) {
        showToast('error', 'Error: ' + err.message);
    }
}


